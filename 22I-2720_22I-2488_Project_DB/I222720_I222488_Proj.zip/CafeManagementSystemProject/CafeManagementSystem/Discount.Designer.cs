﻿namespace CafeManagementSystem
{
    partial class Discount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Discount));
            clearbtn = new Button();
            label6 = new Label();
            label5 = new Label();
            regularpricebtn = new Button();
            Addbtn = new Button();
            Mainmenubtn = new Button();
            close = new Label();
            ManProducts = new Label();
            applydiscountbtn = new Label();
            dataGridView1 = new DataGridView();
            newbox = new TextBox();
            Namebox = new TextBox();
            Idbox = new TextBox();
            NewPricebtn = new Label();
            pronamebtn = new Label();
            productIDbtn = new Label();
            Applydiscountbox = new ComboBox();
            dataGridView2 = new DataGridView();
            label1 = new Label();
            panel1 = new Panel();
            label2 = new Label();
            customerleb = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // clearbtn
            // 
            clearbtn.BackColor = SystemColors.ActiveCaptionText;
            clearbtn.Font = new Font("Garamond", 12F, FontStyle.Bold, GraphicsUnit.Point);
            clearbtn.ForeColor = SystemColors.ButtonFace;
            clearbtn.Location = new Point(795, 512);
            clearbtn.Margin = new Padding(4, 5, 4, 5);
            clearbtn.Name = "clearbtn";
            clearbtn.Size = new Size(176, 43);
            clearbtn.TabIndex = 56;
            clearbtn.Text = "Clear";
            clearbtn.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Garamond", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = SystemColors.ButtonFace;
            label6.Location = new Point(741, 84);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(81, 27);
            label6.TabIndex = 3;
            label6.Text = "Admin";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Garamond", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(549, 80);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(142, 31);
            label5.TabIndex = 2;
            label5.Text = "Username:";
            // 
            // regularpricebtn
            // 
            regularpricebtn.BackColor = SystemColors.ActiveCaptionText;
            regularpricebtn.Font = new Font("Garamond", 12F, FontStyle.Bold, GraphicsUnit.Point);
            regularpricebtn.ForeColor = SystemColors.ButtonFace;
            regularpricebtn.Location = new Point(134, 358);
            regularpricebtn.Margin = new Padding(4, 5, 4, 5);
            regularpricebtn.Name = "regularpricebtn";
            regularpricebtn.Size = new Size(225, 43);
            regularpricebtn.TabIndex = 27;
            regularpricebtn.Text = "Regular Price";
            regularpricebtn.UseVisualStyleBackColor = false;
            regularpricebtn.Click += removebtn_Click;
            // 
            // Addbtn
            // 
            Addbtn.BackColor = SystemColors.ActiveCaptionText;
            Addbtn.Font = new Font("Garamond", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Addbtn.ForeColor = SystemColors.ButtonFace;
            Addbtn.Location = new Point(134, 305);
            Addbtn.Margin = new Padding(4, 5, 4, 5);
            Addbtn.Name = "Addbtn";
            Addbtn.Size = new Size(225, 43);
            Addbtn.TabIndex = 26;
            Addbtn.Text = "Add Discount";
            Addbtn.UseVisualStyleBackColor = false;
            Addbtn.Click += Addbtn_Click;
            // 
            // Mainmenubtn
            // 
            Mainmenubtn.BackColor = SystemColors.ActiveCaptionText;
            Mainmenubtn.Font = new Font("Garamond", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Mainmenubtn.ForeColor = SystemColors.ButtonFace;
            Mainmenubtn.Location = new Point(134, 411);
            Mainmenubtn.Margin = new Padding(4, 5, 4, 5);
            Mainmenubtn.Name = "Mainmenubtn";
            Mainmenubtn.Size = new Size(225, 43);
            Mainmenubtn.TabIndex = 25;
            Mainmenubtn.Text = "Main Menu";
            Mainmenubtn.UseVisualStyleBackColor = false;
            Mainmenubtn.Click += Mainmenubtn_Click;
            // 
            // close
            // 
            close.AutoSize = true;
            close.Font = new Font("Microsoft JhengHei UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            close.ForeColor = SystemColors.ButtonFace;
            close.Location = new Point(949, 16);
            close.Margin = new Padding(4, 0, 4, 0);
            close.Name = "close";
            close.Size = new Size(25, 29);
            close.TabIndex = 1;
            close.Text = "x";
            close.Click += close_Click;
            // 
            // ManProducts
            // 
            ManProducts.AutoSize = true;
            ManProducts.Font = new Font("Garamond", 12F, FontStyle.Bold, GraphicsUnit.Point);
            ManProducts.Location = new Point(542, 352);
            ManProducts.Margin = new Padding(4, 0, 4, 0);
            ManProducts.Name = "ManProducts";
            ManProducts.Size = new Size(128, 27);
            ManProducts.TabIndex = 58;
            ManProducts.Text = " Discounts:";
            // 
            // applydiscountbtn
            // 
            applydiscountbtn.AutoSize = true;
            applydiscountbtn.Font = new Font("Garamond", 11F, FontStyle.Bold, GraphicsUnit.Point);
            applydiscountbtn.Location = new Point(508, 236);
            applydiscountbtn.Margin = new Padding(4, 0, 4, 0);
            applydiscountbtn.Name = "applydiscountbtn";
            applydiscountbtn.Size = new Size(162, 25);
            applydiscountbtn.TabIndex = 57;
            applydiscountbtn.Text = "Apply Discount:";
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(746, 387);
            dataGridView1.Margin = new Padding(4, 5, 4, 5);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(228, 115);
            dataGridView1.TabIndex = 55;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // newbox
            // 
            newbox.Location = new Point(709, 275);
            newbox.Margin = new Padding(4, 5, 4, 5);
            newbox.Name = "newbox";
            newbox.Size = new Size(247, 31);
            newbox.TabIndex = 53;
            // 
            // Namebox
            // 
            Namebox.Location = new Point(709, 191);
            Namebox.Margin = new Padding(4, 5, 4, 5);
            Namebox.Name = "Namebox";
            Namebox.Size = new Size(244, 31);
            Namebox.TabIndex = 52;
            // 
            // Idbox
            // 
            Idbox.Location = new Point(709, 150);
            Idbox.Margin = new Padding(4, 5, 4, 5);
            Idbox.Name = "Idbox";
            Idbox.Size = new Size(244, 31);
            Idbox.TabIndex = 51;
            // 
            // NewPricebtn
            // 
            NewPricebtn.AutoSize = true;
            NewPricebtn.Font = new Font("Garamond", 11F, FontStyle.Bold, GraphicsUnit.Point);
            NewPricebtn.Location = new Point(508, 281);
            NewPricebtn.Margin = new Padding(4, 0, 4, 0);
            NewPricebtn.Name = "NewPricebtn";
            NewPricebtn.Size = new Size(197, 25);
            NewPricebtn.TabIndex = 49;
            NewPricebtn.Text = "Product New Price:";
            // 
            // pronamebtn
            // 
            pronamebtn.AutoSize = true;
            pronamebtn.Font = new Font("Garamond", 11F, FontStyle.Bold, GraphicsUnit.Point);
            pronamebtn.Location = new Point(508, 191);
            pronamebtn.Margin = new Padding(4, 0, 4, 0);
            pronamebtn.Name = "pronamebtn";
            pronamebtn.Size = new Size(157, 25);
            pronamebtn.TabIndex = 48;
            pronamebtn.Text = "Product Name:";
            // 
            // productIDbtn
            // 
            productIDbtn.AutoSize = true;
            productIDbtn.Font = new Font("Garamond", 11F, FontStyle.Bold, GraphicsUnit.Point);
            productIDbtn.Location = new Point(508, 150);
            productIDbtn.Margin = new Padding(4, 0, 4, 0);
            productIDbtn.Name = "productIDbtn";
            productIDbtn.Size = new Size(124, 25);
            productIDbtn.TabIndex = 47;
            productIDbtn.Text = "Product ID:";
            // 
            // Applydiscountbox
            // 
            Applydiscountbox.FormattingEnabled = true;
            Applydiscountbox.Items.AddRange(new object[] { "Percentage ", "Fixed Amount", "Large Sale" });
            Applydiscountbox.Location = new Point(709, 232);
            Applydiscountbox.Margin = new Padding(4, 5, 4, 5);
            Applydiscountbox.Name = "Applydiscountbox";
            Applydiscountbox.Size = new Size(247, 33);
            Applydiscountbox.TabIndex = 59;
            Applydiscountbox.SelectedIndexChanged += Applydiscountbox_SelectedIndexChanged;
            // 
            // dataGridView2
            // 
            dataGridView2.BackgroundColor = Color.White;
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(506, 384);
            dataGridView2.Margin = new Padding(4, 5, 4, 5);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 62;
            dataGridView2.RowTemplate.Height = 25;
            dataGridView2.Size = new Size(228, 118);
            dataGridView2.TabIndex = 60;
            dataGridView2.CellContentClick += dataGridView2_CellContentClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Garamond", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(783, 328);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(170, 54);
            label1.TabIndex = 61;
            label1.Text = "Products In \r\nDiscount Type:";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(label2);
            panel1.Controls.Add(close);
            panel1.Controls.Add(customerleb);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(987, 48);
            panel1.TabIndex = 81;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Garamond", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = SystemColors.ButtonFace;
            label2.Location = new Point(0, 8);
            label2.Name = "label2";
            label2.Padding = new Padding(6);
            label2.Size = new Size(355, 39);
            label2.TabIndex = 0;
            label2.Text = "FAST Cafe Management System";
            // 
            // customerleb
            // 
            customerleb.AutoSize = true;
            customerleb.Font = new Font("Garamond", 14F, FontStyle.Bold, GraphicsUnit.Point);
            customerleb.ForeColor = SystemColors.ButtonFace;
            customerleb.Location = new Point(604, 16);
            customerleb.Margin = new Padding(4, 0, 4, 0);
            customerleb.Name = "customerleb";
            customerleb.Size = new Size(192, 31);
            customerleb.TabIndex = 1;
            customerleb.Text = "Admin's Portal";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.Location = new Point(0, 40);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(499, 548);
            pictureBox1.TabIndex = 80;
            pictureBox1.TabStop = false;
            // 
            // Discount
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkGray;
            ClientSize = new Size(987, 555);
            Controls.Add(panel1);
            Controls.Add(regularpricebtn);
            Controls.Add(label1);
            Controls.Add(Addbtn);
            Controls.Add(dataGridView2);
            Controls.Add(Mainmenubtn);
            Controls.Add(Applydiscountbox);
            Controls.Add(label6);
            Controls.Add(clearbtn);
            Controls.Add(label5);
            Controls.Add(ManProducts);
            Controls.Add(applydiscountbtn);
            Controls.Add(dataGridView1);
            Controls.Add(newbox);
            Controls.Add(Namebox);
            Controls.Add(Idbox);
            Controls.Add(NewPricebtn);
            Controls.Add(pronamebtn);
            Controls.Add(productIDbtn);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 5, 4, 5);
            Name = "Discount";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Discount";
            Load += Discount_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button clearbtn;
        private Label label6;
        private Label label5;
        private Button regularpricebtn;
        private Button Addbtn;
        private Button Mainmenubtn;
        private Label close;
        private Label ManProducts;
        private Label applydiscountbtn;
        private DataGridView dataGridView1;
        private TextBox newbox;
        private TextBox Namebox;
        private TextBox Idbox;
        private Label NewPricebtn;
        private Label pronamebtn;
        private Label productIDbtn;
        private ComboBox Applydiscountbox;
        private DataGridView dataGridView2;
        private Label label1;
        private Panel panel1;
        private Label label2;
        private Label customerleb;
        private PictureBox pictureBox1;
    }
}